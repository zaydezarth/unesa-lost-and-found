package com.unesa.lostandfound

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class TambahLaporanActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_laporan)

        val tvJenisLaporan =
            findViewById<TextView>(R.id.tvJenisLaporan)

        val btnKirim =
            findViewById<Button>(R.id.btnKirim)

        val jenis =
            intent.getStringExtra("jenis")

        tvJenisLaporan.text =
            "Jenis Laporan: $jenis"

        btnKirim.setOnClickListener {

            Toast.makeText(
                this,
                "Laporan berhasil dibuat (sementara)",
                Toast.LENGTH_SHORT
            ).show()

            finish()
        }
    }
}