package com.unesa.lostandfound

data class LaporanBarang(
    val id: String,
    val namaBarang: String,
    val kategori: String,
    val deskripsi: String,
    val jenisLaporan: String,
    val lokasi: String,
    val waktu: String,
    val fotoUrl: String? = null
)