package com.unesa.lostandfound

object MatchingEngine {

    fun hitungKecocokan(
        barangHilang: LaporanBarang,
        barangDitemukan: LaporanBarang
    ): Int {

        var skor = 0

        // Kategori barang sama
        if (barangHilang.kategori.equals(
                barangDitemukan.kategori,
                ignoreCase = true
            )
        ) {
            skor += 30
        }

        // Nama barang sama
        if (barangHilang.namaBarang.equals(
                barangDitemukan.namaBarang,
                ignoreCase = true
            )
        ) {
            skor += 30
        }

        // Lokasi sama
        if (barangHilang.lokasi.equals(
                barangDitemukan.lokasi,
                ignoreCase = true
            )
        ) {
            skor += 20
        }

        // Deskripsi sama
        if (barangHilang.deskripsi.equals(
                barangDitemukan.deskripsi,
                ignoreCase = true
            )
        ) {
            skor += 20
        }

        return skor
    }
}