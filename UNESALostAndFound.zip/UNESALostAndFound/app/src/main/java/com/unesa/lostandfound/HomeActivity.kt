package com.unesa.lostandfound

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btnBarangHilang =
            findViewById<Button>(R.id.btnBarangHilang)

        val btnBarangDitemukan =
            findViewById<Button>(R.id.btnBarangDitemukan)

        val btnDetail =
            findViewById<Button>(R.id.btnDetail)

        val btnProfile =
            findViewById<Button>(R.id.btnProfile)

        btnBarangHilang.setOnClickListener {

            val intent =
                Intent(this, TambahLaporanActivity::class.java)

            intent.putExtra("jenis", "Barang Hilang")
            startActivity(intent)
        }

        btnBarangDitemukan.setOnClickListener {

            val intent =
                Intent(this, TambahLaporanActivity::class.java)

            intent.putExtra("jenis", "Barang Ditemukan")
            startActivity(intent)
        }

        btnDetail.setOnClickListener {

            val intent =
                Intent(this, DetailBarangActivity::class.java)

            startActivity(intent)
        }

        btnProfile.setOnClickListener {

            val intent =
                Intent(this, ProfileActivity::class.java)

            startActivity(intent)
        }
    }
}