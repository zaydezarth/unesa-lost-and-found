package com.unesa.lostandfound

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DetailBarangActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_barang)

        val btnHubungi =
            findViewById<Button>(R.id.btnHubungi)

        btnHubungi.setOnClickListener {

            Toast.makeText(
                this,
                "Fitur hubungi akan dibuat nanti",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}