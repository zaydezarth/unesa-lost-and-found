package com.unesa.lostandfound

object DataContoh {

    val barangHilang = LaporanBarang(
        id = "H001",
        namaBarang = "Dompet Hitam",
        kategori = "Aksesori",
        deskripsi = "Dompet hitam berisi kartu mahasiswa",
        jenisLaporan = "Hilang",
        lokasi = "Gedung A",
        waktu = "10:00"
    )

    val barangDitemukan = LaporanBarang(
        id = "F001",
        namaBarang = "Dompet Hitam",
        kategori = "Aksesori",
        deskripsi = "Dompet hitam berisi kartu mahasiswa",
        jenisLaporan = "Ditemukan",
        lokasi = "Gedung A",
        waktu = "10:30"
    )
}